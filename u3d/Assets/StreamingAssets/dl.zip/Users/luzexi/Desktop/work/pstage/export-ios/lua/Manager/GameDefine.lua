﻿


local function create()
    SCREEN_WIDE = 640
    SCREEN_HEIGHT = 960
end


local t = {}
t.create = create
return t
