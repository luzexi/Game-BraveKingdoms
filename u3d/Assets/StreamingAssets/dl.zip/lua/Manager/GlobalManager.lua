﻿


local function create()
    Battle = {}
    Player = {}
    require("DataTable.datatable")
end


local t = {}
t.create = create
return t