﻿


local function create()
    --
end


local t = {}
t.create = create
return t
